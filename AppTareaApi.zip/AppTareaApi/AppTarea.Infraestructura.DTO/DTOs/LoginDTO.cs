﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppTarea.Infraestructura.DTO.DTOs
{
    public class LoginDTO
    {
        public string userName { get; set; }

        public string password { get; set; }
    }
}
