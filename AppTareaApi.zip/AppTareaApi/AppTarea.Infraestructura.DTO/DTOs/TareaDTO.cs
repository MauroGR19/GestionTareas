﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AppTarea.Infraestructura.DTO.DTOs
{
    public class TareaDTO : AuditoriaDTO
    {
        public Guid tareaId { get; set; }
        public string titulo { get; set; }
        public string descripcion { get; set; }
        public string estado { get; set; }
        public DateTime fechaVencimiento { get; set; }
    }
    
}
