﻿using AppTarea.Dominio.Interfaces.Repositorio;
using AppTarea.Aplicacion.Interfaces;
using AppTarea.Dominio.Response;
using AppTarea.Dominio.Interfaces;

namespace AppTarea.Aplicacion.Servicios
{
    public class TareaServicio : IServicioBase<Tarea, Guid>
    {
        private readonly IRepositorioBase<Tarea, Guid> repoTarea;
        public TareaServicio(IRepositorioBase<Tarea, Guid> _repoTare)
        {
            repoTarea = _repoTare;
        }

        public Task<Response<List<Tarea>>> Listar(string user)
        {
            return repoTarea.Listar(user);
        }

        Task<Response<Tarea>> IAgregar<Tarea>.Agregar(Tarea entidad)
        {
            return repoTarea.Agregar(entidad);
        }

        Task<Response<bool>> IEditar<Tarea>.Editar(Tarea entidad)
        {
            return repoTarea.Editar(entidad);
        }

        Task<Response<bool>> IEliminar<Guid>.Eliminar(Guid entidadId)
        {
            return repoTarea.Eliminar(entidadId);
        }


        Task<Response<bool>> IMarcar<Tarea>.Marcar(Guid tareaId)
        {
            return repoTarea.Marcar(tareaId);
        }

    }
}
