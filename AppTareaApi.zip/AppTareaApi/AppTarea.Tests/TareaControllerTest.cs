using NUnit.Framework;
using AppTarea.Dominio.Interfaces.Repositorio;
using AppTarea.Infraestructura.APII.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NSubstitute;
using AppTarea.Aplicacion.Interfaces;
using AppTarea.Dominio.Response;
using AppTarea.Infraestructura.DTO.DTOs;
using System.Net;
using AppTarea.Infraestructura.APII.Utilities;

namespace AppTarea.Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void cuandoConsultoTareas()
        {
            ////Arrange 
            IServicioBase<Tarea, Guid> repositorioBase = Substitute.For<IServicioBase<Tarea, Guid>>();
            JWToken jWToken = Substitute.For<JWToken>();
            HttpContextService _contextHttp = Substitute.For<HttpContextService>();
            TareaController tareaController = new TareaController(repositorioBase, jWToken, _contextHttp);

            //Act
            var result = tareaController.Get();

            //Assert
            Assert.IsNotNull(result);
        }


        [Test]
        public void cuandoAgregoTareas()
        {
            //Arrange 
            IServicioBase<Tarea, Guid> repositorioBase = Substitute.For<IServicioBase<Tarea, Guid>>();
            JWToken jWToken = Substitute.For<JWToken>();
            HttpContextService _contextHttp = Substitute.For<HttpContextService>();
            TareaController tareaController = new TareaController(repositorioBase, jWToken, _contextHttp);
            TareaDTO tarea = new TareaDTO()
            {
                Creado = DateTime.Now,
                CreadoPor = new Guid("6BD5C8BD-6058-455B-806A-F5D0B13DB454"),
                Actualizado = DateTime.Now,
                ActualizadoPor = new Guid("6BD5C8BD-6058-455B-806A-F5D0B13DB454"),
                tareaId = Guid.NewGuid(),
                descripcion = "Tarea del hogar",
                estado = "Nueva",
            };

            //Act
            var result = tareaController.Post(tarea);

            //Assert
            Assert.IsNotNull(result);

        } 
   
    }

}