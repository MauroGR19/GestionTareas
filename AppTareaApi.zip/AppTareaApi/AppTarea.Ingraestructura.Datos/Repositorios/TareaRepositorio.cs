﻿using AppTarea.Dominio.Interfaces;
using AppTarea.Dominio.Interfaces.Repositorio;
using AppTarea.Dominio.Response;
using AppTarea.Infraestructura.Datos.Contexto;

namespace AppTarea.Infraestructura.Datos.Repositorios
{
    public class TareaRepositorio : IRepositorioBase<Tarea, Guid>
    {
        private AplicattionContexto db;
        public TareaRepositorio(AplicattionContexto _db)
        {
            db = _db;
        }

        Task<Response<Tarea>> IAgregar<Tarea>.Agregar(Tarea entidad)
        {
            try
            {
                entidad.tareaId = Guid.NewGuid();
                entidad.estado = "Nueva";
                entidad.Actualizado = DateTime.Now;
                entidad.Creado = DateTime.Now;
                

                if (entidad != null)
                {
                    if (entidad.fechaVencimiento < DateTime.Today)
                        return Task.FromResult(Response<Tarea>.Error(null!, "La Fecha de vencimiento no puede ser menor a la fecha actual.", null));

                    db.tareas.Add(entidad);
                    db.SaveChanges();
                    return Task.FromResult(Response<Tarea>.Success(entidad, "Tarea agregada exitosamente!!!"));
                }

                return Task.FromResult(Response<Tarea>.Error(null!, "La tarea no puede estar vacio.", null));
            }
            catch (Exception ex)
            {
                return Task.FromResult(Response<Tarea>.Error(null, "Ocurrió un error al agregar la tarea.", ex));
            }
        }

        Task<Response<bool>> IEditar<Tarea>.Editar(Tarea entidad)
        {
            try
            {
                var tareaSeleccionada = db.tareas.FirstOrDefault(c => c.tareaId == entidad.tareaId);
                if (tareaSeleccionada != null)
                {

                    if (tareaSeleccionada.estado.ToUpper() == "COMPLETADA")
                        return Task.FromResult(Response<bool>.Error(false, "No se puede editar una tarea que cuenta con el estado Finalizada.", null));

                    if (entidad.fechaVencimiento < DateTime.Today)
                        return Task.FromResult(Response<bool>.Error(false, "La fecha de vencimiento no puede ser menor a la actual.", null));

                    // Aplicar las ediciones restantes
                    tareaSeleccionada.descripcion = entidad.descripcion;
                    tareaSeleccionada.fechaVencimiento = entidad.fechaVencimiento;
                    entidad.Actualizado = DateTime.Now;

                    db.Entry(tareaSeleccionada).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    db.SaveChanges();
                    return Task.FromResult(Response<bool>.Success(true, "La tarea se editó correctamente."));
                }

                return Task.FromResult(Response<bool>.Error(false, "La tara no fue encontrada.", null));
            }
            catch (Exception ex)
            {
                return Task.FromResult(Response<bool>.Error(false, "Ocurrió un error al editar la tarea.", ex));
            }
        }


        Task<Response<bool>> IEliminar<Guid>.Eliminar(Guid entidadId)
        {
            try
            {
                var tareasSeleccionada = db.tareas.Where(c => c.tareaId == entidadId).FirstOrDefault();
                if (tareasSeleccionada != null)
                {
                    if (tareasSeleccionada.estado.ToUpper() == "COMPLETADA")
                        return Task.FromResult(Response<bool>.Error(false, "No se pueden eliminar tareas con los estados Finalizada, En Proceso.", null));

                    db.tareas.Remove(tareasSeleccionada);
                    db.SaveChanges();
                    return Task.FromResult(Response<bool>.Success(true, "La tarea se elimino correctamente."));
                }

                return Task.FromResult(Response<bool>.Error(false, "La tara no fue encontrada.", null));

            }
            catch (Exception ex)
            {
                return Task.FromResult(Response<bool>.Error(false, "Ocurrió un error al Eliminar la tarea.", ex));
            }
        }


        public Task<Response<List<Tarea>>> Listar(string user)
        {
            try
            {
                var tareas = db.tareas.Where(a=> a.CreadoPor == new Guid(user)).ToList();
                return Task.FromResult(Response<List<Tarea>>.Success(tareas, "Operacion exitosa"));
            }
            catch (Exception ex)
            {
                return Task.FromResult(Response<List<Tarea>>.Error(null, "Ocurrió un error al listar las tareas.", ex));
            }
        }

        public Task<Response<bool>> Marcar(Guid tareaId)
        {
            try
            {
                var tareaSeleccionada = db.tareas.FirstOrDefault(c => c.tareaId == tareaId);

                if (tareaSeleccionada == null)
                {
                    return Task.FromResult(Response<bool>.Error(false, "La tarea no fue encontrada.", null));
                }

                tareaSeleccionada.estado = "COMPLETADO";

                db.Entry(tareaSeleccionada).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                db.SaveChanges();
                return Task.FromResult(Response<bool>.Success(true, "La tarea se marco como completado corecctamente."));
            }
            catch (Exception ex)
            {
                return Task.FromResult(Response<bool>.Error(false, "Ocurrio un error al completar la tarea", ex));
            }
        }
    }
}
