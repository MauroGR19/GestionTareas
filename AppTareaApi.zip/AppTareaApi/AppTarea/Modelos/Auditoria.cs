﻿namespace AppTarea
{
    public class Auditoria
    {
        public DateTime? Creado { get; set; }
        public Guid? CreadoPor { get; set; }
        public DateTime? Actualizado { get; set; }
        public Guid? ActualizadoPor { get; set; }
    }
}
