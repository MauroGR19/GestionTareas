﻿using System.ComponentModel.DataAnnotations.Schema;

namespace AppTarea
{
    public class Tarea : Auditoria
    {
        public Guid tareaId { get; set; }
        public string titulo { get; set; }
        public string descripcion { get; set; }
        public string estado { get; set; }
        public DateTime fechaVencimiento { get; set; }
    }
}
