import { HttpInterceptorFn } from '@angular/common/http';

export const customInterceptor: HttpInterceptorFn = (req, next) => {
  
  const myToken = localStorage.getItem('Token');
  const cloneRequest =  req.clone({
    setHeaders:{
      Authorization: `Bearer ${myToken}`,
      'x-api-key': 'MauricioGomezXAPIKEY'
    }
  });
  return next(cloneRequest);
};
