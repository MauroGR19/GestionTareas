import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Tarea } from '../interface/interface/tarea';

@Injectable({
  providedIn: 'root'
})
export class TareaService {
  
  
  constructor(private http: HttpClient) {

  }

  getTareasUser(): Observable<Tarea[]> {
    // Realiza la solicitud HTTP y devuelve el Observable resultante
    return this.http.get<Tarea[]>('http://localhost:8181/api/Tarea')
  };
  
  
  add(modelo:Tarea): Observable<Tarea>{
    // return this.http.post<Tarea>(`${this.urlApi}`, modelo);
    return this.http.post<Tarea>('http://localhost:8181/api/Tarea',modelo)
  };
  
  update(modelo:Tarea): Observable<Tarea>{
    // return this.http.post<Tarea>(`${this.urlApi}`, modelo);
    return this.http.put<Tarea>('http://localhost:8181/api/Tarea',modelo)
  };
  

  delete(idTarea:string): Observable<Tarea>{
    // return this.http.post<Tarea>(`${this.urlApi}`, modelo);
    return this.http.delete<Tarea>(`http://localhost:8181/api/Tarea/${idTarea}`)
  };

  
  marcarTarea(idTarea: string): Observable<Tarea> {
    return this.http.post<Tarea>(`http://localhost:8181/api/Tarea/Marcar/${idTarea}`,null)
  };
  
}
