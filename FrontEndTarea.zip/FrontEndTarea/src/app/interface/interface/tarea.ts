export interface Tarea {
    tareaId:string,
    titulo:string, 
    descripcion:string,
    estado:string, 
    fechaVencimiento:Date,
    CreadoPor:string,
    ActualizadoPor:string
}
