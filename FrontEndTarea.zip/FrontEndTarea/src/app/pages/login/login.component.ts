import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, HttpClientModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  loginObj: Login;

  constructor(private http: HttpClient, private router : Router,private _snackBar: MatSnackBar) {
    this.loginObj = new Login();
   
  }

  mostrarAlerta(message: string, action: string) {
    this._snackBar.open(message, action, {
      horizontalPosition:"end",
      verticalPosition:"top",
      duration:3000
    });
  }

  onLogin(): void {
    
    if(this.loginObj.password.length == 0 || this.loginObj.userName.length ==0){
      this.mostrarAlerta("Usuario o contraseña invalidos!","fallo");
    }else{
      this.http.post('http://localhost:8181/api/Usuario', this.loginObj).subscribe((res:any)=>{
      debugger;
      if(res.code == 200) {
        this.mostrarAlerta("Login exitoso!","listo");
        localStorage.setItem('Token', res.token)
        localStorage.setItem('user', res.user.usuarioId)
        this.router.navigateByUrl('/dashboard')
      } else {

        debugger;
        alert("Verifique sus credenciales")
      }
    })
    }

    

  }

  onRegister(): void {
    this.router.navigateByUrl('/register')
  }
}

export class Login {
    userName: string;
    password: string;
    constructor() {
      this.userName = '';
      this.password = '';
    }
}
