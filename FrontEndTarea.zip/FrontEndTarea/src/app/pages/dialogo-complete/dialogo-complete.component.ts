import { Component, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog'
import { Tarea } from '../../interface/interface/tarea';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-dialogo-complete',
  standalone: true,
  imports: [CommonModule, MatDialogModule,MatButtonModule],
  templateUrl: './dialogo-complete.component.html',
  styleUrl: './dialogo-complete.component.css'
})
export class DialogoCompleteComponent {

  constructor(
    private dialogoReferencia: MatDialogRef<DialogoCompleteComponent>,
    @Inject(MAT_DIALOG_DATA) public dataTarea:Tarea
  ){}

  confrimar_Completada(){
    if(this.dataTarea){
      this.dialogoReferencia.close("completada")
    }
  }

}
