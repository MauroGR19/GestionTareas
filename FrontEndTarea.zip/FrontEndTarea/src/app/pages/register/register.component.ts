import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { v4 as uuidv4 } from 'uuid';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, HttpClientModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  RegisterObj: Register;

  constructor(private http: HttpClient, private router : Router,private _snackBar: MatSnackBar) {
    this.RegisterObj = new Register()
   
  }

  mostrarAlerta(message: string, action: string) {
    this._snackBar.open(message, action, {
      horizontalPosition:"end",
      verticalPosition:"top",
      duration:3000
    });
  }

  onRegister(): void {
    function generarGUID(): string {
      return uuidv4();
    }

    this.RegisterObj.usuarioId = generarGUID();

    if(this.RegisterObj.contrasena.length == 0 || this.RegisterObj.nombre.length ==0){
      this.mostrarAlerta("Usuario o contraseña invalidos!","fallo");
    }else{
      this.http.post('http://localhost:8181/api/Usuario/Agregar', this.RegisterObj).subscribe((res:any)=>{
      if(res) {
        this.mostrarAlerta("Registro Exitoso","listo")
        this.router.navigateByUrl('/login')
      } else {
        this.mostrarAlerta("Algo fallo al intentar registrarse","fallo")
      }
    })}
      
  }

  onRegisterCancel(){
    this.mostrarAlerta("Registro Cancelado","Listo")
    this.router.navigateByUrl('/login')
  }

}

export class Register {
  usuarioId:string;
  nombre: string;
  contrasena: string;
  constructor() {
    this.nombre = '';
    this.contrasena = '';
    this.usuarioId = '';
  }
}