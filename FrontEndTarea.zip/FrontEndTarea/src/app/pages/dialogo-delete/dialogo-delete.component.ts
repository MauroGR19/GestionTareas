import { Component, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog'
import { Tarea } from '../../interface/interface/tarea';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-dialogo-delete',
  standalone: true,
  imports: [CommonModule, MatDialogModule,MatButtonModule],
  templateUrl: './dialogo-delete.component.html',
  styleUrl: './dialogo-delete.component.css'
})
export class DialogoDeleteComponent {

  constructor(
    private dialogoReferencia: MatDialogRef<DialogoDeleteComponent>,
    @Inject(MAT_DIALOG_DATA) public dataTarea:Tarea
  ){}

  confrimar_Eliminar(){
    if(this.dataTarea){
      this.dialogoReferencia.close("eliminar")
    }
  }
}
