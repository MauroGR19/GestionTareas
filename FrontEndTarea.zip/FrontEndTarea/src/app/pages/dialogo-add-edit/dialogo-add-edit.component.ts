import { Component ,model,OnInit, Inject} from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import {FormBuilder,FormGroup, Validators} from '@angular/forms';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog'
import { MatSnackBar } from '@angular/material/snack-bar';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import * as moment from 'moment'
import { Tarea } from '../../interface/interface/tarea';
import { TareaService } from '../../service/tarea.service';
import { MatGridListModule } from '@angular/material/grid-list';
import { ReactiveFormsModule } from '@angular/forms';
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatButtonModule } from '@angular/material/button';
import { v4 as uuidv4 } from 'uuid';


export const MY_DATE_FORMATS = {
  parse:{
    dateImput: 'DD/MM/YYYY',
  },
  display:{
    dateImput: 'DD/MM/YYYY',
    monthYearLabel: 'MMMMM/YYYY',
    dateA11yLabel: 'LL',
    montYearA11yLabel: 'MMMMM/YYYY'
  }
}

@Component({
  selector: 'app-dialogo-add-edit',
  standalone: true,
  imports: [
    MatDialogModule,
    MatGridListModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    MatIconModule,
    MatInputModule,
    MatDatepickerModule,
    MatButtonModule
  ],
  templateUrl: './dialogo-add-edit.component.html',
  styleUrl: './dialogo-add-edit.component.css',
  providers:[
    {provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS}
  ]
})
export class DialogoAddEditComponent {

  formTarea:  FormGroup; 
  tituloAccion: string = "Nueva";
  botonAccion: string = "Guardar";
  listaTarea: Tarea[] = [];

  constructor(
    private dialogoReferencia: MatDialogRef<DialogoAddEditComponent>,
    private fb:FormBuilder,
    private _snackBar: MatSnackBar,
    private _tareaServicio: TareaService ,
    @Inject(MAT_DIALOG_DATA) public dataTarea:Tarea
  ){
    this.formTarea = this.fb.group({
      titulo:["",Validators.required],
      description:["",Validators.required],
      fechaVencimiento:["",Validators.required]
    })


    this._tareaServicio.getTareasUser().subscribe((res: any) => {
      if (res) {
        this.listaTarea = res.data;
      } else {
        // Si la respuesta no contiene datos, muestra un mensaje de error o maneja la situación según sea necesario
        console.error('La respuesta del servidor no contiene datos válidos.');
      }
    });
  
  }

  mostrarAlerta(message: string, action: string) {
    this._snackBar.open(message, action, {
      horizontalPosition:"end",
      verticalPosition:"top",
      duration:3000
    });
  }


  addEditTarea(){
    
    function generarGUID(): string {
      return uuidv4();
    }

    const modelo:Tarea={
      
      tareaId: generarGUID(),
      titulo: this.formTarea.value.titulo,
      descripcion: this.formTarea.value.description,
      estado:"", 
      fechaVencimiento: this.formTarea.value.fechaVencimiento,
      CreadoPor: localStorage.getItem('user') || '',
      ActualizadoPor: localStorage.getItem('user') || '',
    }

    if(this.dataTarea == null){
      this._tareaServicio.add(modelo).subscribe((res: any) =>{
        if (res) {
          this.mostrarAlerta(res.mensaje,"Listo")
          this.dialogoReferencia.close("creado")
        } else {
          // Si la respuesta no contiene datos, muestra un mensaje de error o maneja la situación según sea necesario
          this.mostrarAlerta(res.mensaje,"Error")
        }
      })
    }else{
      modelo.tareaId = this.dataTarea.tareaId;
      this._tareaServicio.update(modelo).subscribe((res: any) =>{
        if (res) {
          this.mostrarAlerta(res.mensaje,"Listo")
          this.dialogoReferencia.close("editado")
        } else {
          // Si la respuesta no contiene datos, muestra un mensaje de error o maneja la situación según sea necesario
          this.mostrarAlerta(res.mensaje,"Error")
        }
      })
    }


    
  }

  ngOnInit(): void{
    if(this.dataTarea){
      this.formTarea.patchValue({
        titulo: this.dataTarea.titulo,
        description: this.dataTarea.descripcion,
        fechaVencimiento: this. dataTarea.fechaVencimiento
      })
      this.tituloAccion = "Editar";
      this.botonAccion = "Actualizar"
    }

    
  }
  
}
